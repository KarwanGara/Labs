const express = require('express');
const app = express();
const port = 3000;
const routes = require("./routes");


//första routen
app.get('/', (req, res) => {
    res.send('h19karwg@du.se');
});
app.use(express.json());
app.use('/api/', routes);
app.listen(port, () => {
     console.log(`Listening on ${port}`)
});
