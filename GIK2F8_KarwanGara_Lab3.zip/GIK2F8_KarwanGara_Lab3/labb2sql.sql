
-- SQLite
DROP TABLE IF EXISTS products;
CREATE TABLE IF NOT EXISTS products (
    name varchar(32),
    description varchar(128),
    price varchar(32),
    id INTEGER UNIQUE);

INSERT INTO products (name, description, price, id) VALUES
    ('Naruto', 'An Anime series about ninjas.', '299 SEK', 1),
    ('One Piece', 'An Anime series about pirates.', '499 SEK', 2),
    ('Bleach', 'An Anime series about reapers.', '199 SEK', 3),
    ('Fairy Tail', 'An Anime series about mages.', '399 SEK', 4),
    ('My Hero Academia', 'An Anime series about heroes.', '99 SEK', 5);

DROP TABLE IF EXISTS users;
CREATE TABLE IF NOT EXISTS users (
    email varchar(64) UNIQUE,
    firstname varchar(32),
    surname varchar(32),
    password varchar(32),
    id INTEGER UNIQUE);

INSERT INTO users (email, firstname, surname, password, id) VALUES
    ('h19karwg@du.se', 'Karwan', 'Gara','safepassword', 1),
    ('h19phike@du.se', 'Philip', 'Kelli','safepassword2', 2),
    ('h19simgh@du.se', 'Simko', 'Ghaderi','safepassword3', 3),
    ('h19sakah@du.se', 'Sakeria', 'Kaysa','safepassword4', 4);