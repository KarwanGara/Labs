
// require sqlite to be able to use CRUD-OPERATIONS on our database
const sqlite3 = require('sqlite3');
const { open } = require('sqlite');
const routes = require('./routes');

// create a database promise object by connecting to database
const dbPromise = (async () => {
    return open({
        filename: './database.sqlite',
        driver: sqlite3.Database
    });
})();

const Login = async (data) => {
    console.log(data);
    try {
        const dbCon = await dbPromise
        const username = await dbCon.get(`SELECT username FROM users WHERE email=? AND password=?`, [data.email, data.password]);
        if (username === undefined) {
            return {error: 'Access Denied! Revise your information.'};
        }
        else {
            return username;
        }
    }
    catch (error) {
        throw new Error('ERROR ERROR, PROCEEDING WITH SELF DESTRUCT SEQUENCE IN 3.. 2.. 1..');
    }
}

const getUsers = async () => {
    //returnera användare
    try {
        const dbCon = await dbPromise;
        const users = await dbCon.all('SELECT firstname, surname, email, id FROM users ORDER BY id ASC');
        return users;

    }
    catch (error) {
        throw new Error('ERROR ERROR, PROCEEDING WITH SELF DESTRUCT SEQUENCE IN 3.. 2.. 1..')
    }
};

const getProducts = async () => {
    //returnera produkter
    try {
        const dbCon = await dbPromise;
        const products = await dbCon.all('SELECT name, description, price, id FROM products ORDER by id ASC')
        return products;
    }
    catch (error) {
        throw new Error('ERROR ERROR, PROCEEDING WITH SELF DESTRUCT SEQUENCE IN 3.. 2.. 1..')
    }
};

const ProdById = async() => {
    try {
        const dbCon = await dbPromise;
        const products = await dbCon.all('SELECT name, description, price, id FROM products ORDER by id ASC')
        return products;
    }
    catch (error) {
        throw new Error('ERROR ERROR, PROCEEDING WITH SELF DESTRUCT SEQUENCE IN 3.. 2.. 1..')
    }
}

const UserById = async() => {
    try {
        const dbCon = await dbPromise;
        const users = await dbCon.all('SELECT firstname, surname, email, id FROM users ORDER BY id ASC')
        return users;
    }
    catch (error) {
        throw new Error('ERROR ERROR, PROCEEDING WITH SELF DESTRUCT SEQUENCE IN 3.. 2.. 1..')
    }
}

const AddProd = async (data) => {
    try {
        const dbCon = await dbPromise;
        await dbCon.run(`INSERT INTO products (name, description, price) VALUES(?,?,?)`, [data.name, data.description, data.price]);
        return { status: "ok"};
    }
    catch(error) {
        throw new Error('ERROR ERROR, PROCEEDING WITH SELF DESTRUCT SEQUENCE IN 3.. 2.. 1..')
    }
}

const DeleteProd = async (id) => {
    try {
        const dbCon = await dbPromise;
        await dbCon.run("DELETE FROM products WHERE id=?", [id]);
        return {status: 'Product Removed'};
    }
    catch (error) {
        throw new Error('ERROR ERROR, PROCEEDING WITH SELF DESTRUCT SEQUENCE IN 3.. 2.. 1..')
    }
}


module.exports = {
    getUsers: getUsers,
    getProducts: getProducts,
    ProdById: ProdById,
    Login: Login,
    UserById: UserById,
    DeleteProd: DeleteProd,
    AddProd: AddProd
};